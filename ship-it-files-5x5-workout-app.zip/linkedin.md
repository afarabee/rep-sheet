I used to compete in powerlifting. State records, national records, one world record. 🏋️‍♀️

Then life happened and I didn't touch a barbell for two years.

Going back to basics means a 5x5 program -- and building the exact app I need to track it. 💪

Meet Rep Sheet. It's a mobile-first workout tracker I'm building with Lovable + Claude Code + Supabase. Voice entry so I can say "225 for 5" between sets instead of typing with chalky hands. A shoulder exercise rotation picker for my injury workarounds. Progressive overload logic with deload suggestions.

And my favorite part -- my Fitdays scale doesn't export data. Only screenshots. So I built an AI-powered screenshot parser using Claude's vision API that extracts alllllllllllll my body comp metrics automatically. 🤖📸

The hardest part? Scoping. I wanted to build a full custom workout app on day one. But I caught myself doing the thing I tell people at work not to do -- designing for abstract future users instead of shipping for the one standing in the garage right now.

Build for the user you are today. Even when that user is you.

More soon as this one comes together. 🔥

#PowerLifting #VibeCoding #Claude #Anthropic #BuildInPublic #AIwithAimee #Lovable #Supabase
