# Nano Banana Image Prompts: Rep Sheet

## Prompt 1: The Concept
Super Aimee standing in a neon-lit garage gym, hands on a loaded barbell on a squat rack, looking determined. A glowing holographic phone screen floats beside her showing "Workout A" with set indicators. Dust particles in the air catch the neon light. Cyberpunk comic-book style.

## Prompt 2: The Build
Super Aimee sitting cross-legged on a weight bench with a laptop, code streaming across the screen in neon green and purple. Barbell plates are stacked around her like building blocks. A speech bubble shows "225 for 5" with sound wave lines. Neon cyberpunk comic-book art style.

## Prompt 3: The Aha Moment
Super Aimee holding up a phone showing a Fitdays screenshot in one hand, while her other hand catches glowing data points (weight, body fat %, muscle mass) floating out of the screen like particles being extracted. Her expression is a confident grin. Neon cyberpunk comic-book art style.

## Prompt 4: The Ship
Super Aimee walking toward a glowing squat rack with "REP SHEET" in neon letters above it, phone in her back pocket, chalk dust on her hands, a confident stride. Behind her, a wall of holographic workout logs scrolls upward. Neon cyberpunk comic-book art style, triumphant energy.
